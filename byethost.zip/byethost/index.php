<?php
    require "config.php";
    include_once DBAPI;
    require_once ABSPATH . "inc/permissoes.php";
    if (!isset($_SESSION)) session_start();
    include(HEADER_TEMPLATE);
    $db = open_database();
?>

<h1>Dashboard</h1>

<hr/>

<?php if ($db): ?>

    <div class="row  mt-2">
        <div class="col-xs-12 col-md-2">
            <?php if (usuario_logado()) : ?>
            <a href="customers/add.php" class="btn btn-azul col-xs-12">
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <i class="fa-solid fa-user-plus fa-5x"></i>
                    </div>
                    <div class="col-xs-12 text-center">
                        <p>Novo Cliente</p>
                    </div>
                </div>
            </a>
            <?php endif; ?>
        </div>

        <div class="col-xs-12 col-md-2">
            <a href="customers/" class="btn btn-atu col-xs-12">
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <i class="fa-solid fa-users fa-5x"></i>
                    </div>
                    <div class="col-xs-12 text-center">
                        <p>Clientes</p>
                    </div>
                </div>
            </a>
        </div>
    </div>

<!-- Tema -->
    <div class="row mt-2">
        <div class="col-xs-12 col-md-2 ">
            <?php if (usuario_logado()) : ?>
            <a href="imoveis/add.php" class="btn btn-azul col-xs-12">
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <i class="fa-solid fa-house-medical fa-5x"></i>                
                    </div>
                    <div class="col-xs-12 text-center">
                        <p>Novo Imóvel</p>
                    </div>
                </div>
            </a>
            <?php endif; ?>
        </div>

        <div class="col-xs-12 col-md-2">
            <a href="imoveis/" class="btn btn-atu col-xs-12">
                <div class="row">
                    <div class="col-xs-12 text-center">
                        <i class="fa-solid fa-house fa-5x"></i>
                    </div>
                    <div class="col-xs-12 text-center">
                        <p>Imóveis</p>
                    </div>
                </div>
            </a>
        </div>
    </div>

<!-- Usuários: somente administrador -->
    <?php if (usuario_admin()) : ?>
    <div class="row mt-2">
        <div class="col-xs-12 col-md-2">
            <a href="usuarios/" class="btn btn-secondary col-xs-12">
                <div class="row">
                    <div class="col-xs-12 text-center"><i class="fa-solid fa-users-gear fa-5x"></i></div>
                    <div class="col-xs-12 text-center"><p>Gerenciar usuários</p></div>
                </div>
            </a>
        </div>
        <div class="col-xs-12 col-md-2">
            <a href="usuarios/add.php" class="btn btn-secondary col-xs-12">
                <div class="row">
                    <div class="col-xs-12 text-center"><i class="fa-solid fa-user-tie fa-5x"></i></div>
                    <div class="col-xs-12 text-center"><p>Novo usuário</p></div>
                </div>
            </a>
        </div>
    </div>
    <?php endif; ?>

    <!-- <div class="alert alert-danger" role="alert">
        <p><strong>ERRO:</strong> Não foi possível Conectar ao Banco de Dados!</p>
    </div> -->

        <?php if (!empty($_SESSION['message'])) : ?>
        <div class="alert alert-<?php echo $_SESSION['type']; ?> alert-dismissible" role="alert">
            <p><strong>ERRO:</strong> Não foi possível Conectar ao Banco de Dados!<br>
                <?php echo $_SESSION['message']; ?>
            </p>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php clear_messages(); ?>
    <?php endif; ?>

<?php endif; ?>

<?php include(FOOTER_TEMPLATE); ?>