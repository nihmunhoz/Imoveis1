<?php
    include "config.php";
    include DBAPI;
    include HEADER_TEMPLATE;
    $db = open_database();
?>



<style>
	div. h1{
		font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
	
	}
.info{
	background-color: rgba(129, 129, 129, 0.05);
	border: solid 2px rgba(129, 129, 129, 0.3);
	border-radius: 10px;
}
.grafico{
	border-radius:  5px black;


}
.center{
	width: 50%px; /* or any specific width */
  margin-left: auto;
  margin-right: auto;
}

.centrotexto{
	font-weight: bold;
	color: #023047;
	text-align: center;
	margin-bottom: 20px;
}

</style>

<!-- Gráfico 1 -->
<script>
window.onload = function () {

var options = {
	animationEnabled: true,
	title: {
		text: ""
	},
	axisY: {
		title: "Dados em %",
		suffix: "%"
	},
	axisX: {
		title: "Regiões"
	},
	data: [{
		type: "column",
		yValueFormatString: "#,##0.0#"%"",
		dataPoints: [
			{ label: "Norte", y: 10.09 },	
			{ label: "Nordeste", y: 9.40 },	
			{ label: "Centro-Oeste", y: 8.50 },
			{ label: "Sul", y: 7.96 },	
			{ label: "Sudeste", y: 7.1 }
			
		]
	}]
};
$("#chartContainer").CanvasJSChart(options);

}
function mostrarRegiao(regiao, event) {

    // Evita que a página recarregue
    event.preventDefault();

    // Elemento onde o conteúdo será exibido
    let conteudo = document.getElementById("conteudoRegiao");

    // Verifica qual região foi escolhida
    switch (regiao) {

        case "Norte":
            conteudo.innerHTML = `
                <h4>Região Norte</h4>
                <p>Informações sobre as vendas da região Norte.</p>
                <p>Total de vendas: 10,1%</p>
            `;
            break;

        case "Nordeste":
            conteudo.innerHTML = `
                <h4>Região Nordeste</h4>
                <p>Informações sobre as vendas da região Nordeste.</p>
                <p>Total de vendas: 9,4%</p>
            `;
            break;

        case "Centro-Oeste":
            conteudo.innerHTML = `
                <h4>Região Centro-Oeste</h4>
                <p>Informações sobre as vendas da região Centro-Oeste.</p>
                <p>Total de vendas: 8,5%</p>
            `;
            break;

        case "Sudeste":
            conteudo.innerHTML = `
                <h4>Região Sudeste</h4>
                <p>Informações sobre as vendas da região Sudeste.</p>
                <p>Total de vendas: 7,1%</p>
            `;
            break;

        case "Sul":
            conteudo.innerHTML = `
                <h4>Região Sul</h4>
                <p>Informações sobre as vendas da região Sul.</p>
                <p>Total de vendas: 8,0%</p>
            `;
            break;
    }
}

</script>
<div class="container center">
	<div class="row mt-4"> 
		<div class=" col-md-6 grafico">
			<div  id="chartContainer" style="height: 370px;"></div>
		</div>
		
		<div class=" info col-md-6 "><h1 class="centrotexto">Informações do gráfico</h1>
			<div class="dropdown">
			<button class="btn btn-regiao dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
				Escolha a região desejada
			</button>
			<ul class="dropdown-menu">
				<li><a class="dropdown-item" onclick="mostrarRegiao('Norte', event)" href="#">Norte</a></li>
				<li><a class="dropdown-item" onclick="mostrarRegiao('Nordeste', event)" href="#">Nordeste</a></li>
				<li><a class="dropdown-item" onclick="mostrarRegiao('Centro-Oeste', event)" href="#">Centro-Oeste</a></li>
				<li><a class="dropdown-item" onclick="mostrarRegiao('Sudeste', event)" href="#">Sudeste</a></li>
				<li><a class="dropdown-item" onclick="mostrarRegiao('Sul', event)" href="#">Sul</a></li>
			</ul>
			    <!-- Conteúdo que será alterado -->
			<div id="conteudoRegiao" class="mt-3">
				<p>Selecione uma região para visualizar as informações.</p>
			</div>
			</div>
		</div>
	</div>

</div>






<?php include(FOOTER_TEMPLATE); ?>