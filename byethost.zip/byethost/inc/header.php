<?php require_once __DIR__ . "/permissoes.php"; ?>
<!DOCTYPE html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>CRUD com Bootstrap</title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="<?php echo BASEURL; ?>img/icone-branco.png">

  <link rel="stylesheet" href="<?php echo BASEURL; ?>css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo BASEURL; ?>css/all.css">
  <link rel="stylesheet" href="<?php echo BASEURL; ?>css/style.css">
  <link href="<?php echo BASEURL; ?>lightbox/css/lightbox.css" rel="stylesheet">
  
  <style>
    body {
      padding-bottom: 20px;
    }
    .vacuo{
      background-color: #5c5c5c;
    }

    .btn-light{
      background-color: #6b6b6b;
      border-color: #6b6b6b;
      color: #ffff;
    }

    .btn-light:hover{
      background-color: #5c5c5c;
      border-color: #5c5c5c;
      color: #ffff;
    }

    /* Estilo para dropdown */

    .dropdown-menu {
      background-color: #023047  !important;
    }

    .dropdown-menu .dropdown-item {
      color: #ffffffbb !important;
      background-color: transparent !important;
    }

    .dropdown-menu .dropdown-item:hover {
      background-color: #023047 !important;
      color: white !important;
    }

    .img-logo{
      max-width: 25px;
      height: auto;
      margin: 2px;
    }

    header, #actions {
      margin-top: 10px;
    }
    .bg-nave{
       background-color: #023047 !important;
    }

    .btn-azul{
      background-color: #219ebc;
	    color: white;
    }
    .btn-azul:hover{
      background-color: #219ebc;
	    color: white;
    }
     .btn-azul:active{
      background-color: #219ebc !important;
	    color: white !important;
    }

    .btn-vizu{
      background-color: #1e6091;
	    color: white ;
    }
    .btn-vizu:hover{
      background-color: #1e6091;
	    color: white ;
    }
    .btn-vizu:active{
      background-color: #1e6091 !important;
	    color: white !important;
    }

    .btn-edit{
      background-color: #caf0f8;
	    color: white ;
    }
    .btn-edit:hover{
      background-color: #caf0f8;
	    color: white ;
    }
    .btn-edit:active{
      background-color: #caf0f8 !important;
	    color: white !important;
    }
    
      .btn-atu{
      background-color: #d8e2dc;
	    color: #1e8491;
    }
    .btn-atu:hover{
      background-color: #d8e2dc;
	    color: #1e8491 ;
    }
    .btn-atu:active{
      background-color: #d8e2dc !important;
	    color: #1e8491 !important;
    }
   
    .btn-can{
      background-color: #e0afa0;
	    color: white;
    }
    .btn-can:hover{
      background-color: #e0afa0;
	    color: white ;
    }
    .btn-can:active{
      background-color: #e0afa0 !important;
	    color: white !important;
    }
    
.btn-regiao{
	background-color: #023047;
	color: white;
}
.btn-regiao:hover{
	background-color: #023047;
	color: white;
}
.btn-regiao:active{
	background-color: #023047 !important;
	color: white !important;
}
.btn-regiao:focus{
	background-color: #023047 !important;
	color: white !important;
}
  </style>

</head>

<body>

  <main class="container principal">
    <nav class="navbar navbar-expand-lg navbar-dark bg-nave mb-3">
      <div class="container-fluid">

        <a class="navbar-brand" href="<?php echo BASEURL; ?>"> <img class="img-logo" src="<?php echo BASEURL; ?>img/icone-branco.png">
           CRUD
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarproj"
          aria-controls="#navbarproj" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarproj">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa-solid fa-users"></i> Clientes
              </a>
              <ul class="dropdown-menu dropdown">
                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>customers"><i class="fa-solid fa-users"></i> Gerenciar Clientes</a></li>
                <?php if (usuario_logado()) : ?>
                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>customers/add.php"><i class="fa-solid fa-user-plus"></i> Novo Cliente</a></li>
                <?php endif; ?>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa-solid fa-house"></i> Imóveis
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>imoveis"><i class="fa-solid fa-house"></i> Gerenciar Imóveis</a></li>
                <?php if (usuario_logado()) : ?>
                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>imoveis/add.php"><i class="fa-solid fa-house-medical"></i> Novo Imóvel</a></li>
                <?php endif; ?>
              </ul>
            </li>
            <li class="nav-item"><a class="nav-link" href="<?php echo BASEURL; ?>img"><i class="fa-solid fa-image"></i> Galeria</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo BASEURL; ?>grafico.php"><i class="fa-solid fa-chart-simple"></i> Gráfico</a></li>
            <?php if (usuario_admin()) : ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-user-lock"></i> Usuários</a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>usuarios"><i class="fa-solid fa-user-gear"></i> Gerenciar usuários</a></li>
                <li><a class="dropdown-item" href="<?php echo BASEURL; ?>usuarios/add.php"><i class="fa-solid fa-user-tie"></i> Novo usuário</a></li>
              </ul>
            </li>
            <?php endif; ?>
          </ul>
          <ul class="navbar-nav flex ms-md-auto">
            <?php if (usuario_logado()) : ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo BASEURL; ?>inc/logout.php"><i class="fa-solid fa-person-walking-arrow-right"></i> Desconectar-se de <?php echo htmlspecialchars($_SESSION['user']); ?></a></li>
            <?php else : ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo BASEURL; ?>inc/login.php"><i class="fa-solid fa-users"></i> Login</a></li>
            <?php endif; ?>
          </ul>
        </div>

      </div>
    </nav>