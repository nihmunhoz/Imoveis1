<?php
// 1. Inicia a sessão ANTES de qualquer HTML.
// Isso permite armazenar dados e mensagens para outras páginas.
session_start();

// 2. Carrega as configurações e as funções do banco de dados.
require_once("../config.php");
require_once(DBAPI);

// 3. Se o arquivo não foi enviado pelo formulário (POST),
// retorna para a página inicial.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: " . BASEURL . "index.php");
    exit;
}

// 4. Recebe os dados enviados pelo formulário.
// O operador ?? evita erros caso os campos não existam.
$usuario = trim($_POST["login"] ?? "");
$senha = $_POST["senha"] ?? "";

// 5. Verifica se os campos estão preenchidos.
if ($usuario === "" || $senha === "") {
    $_SESSION["message"] = "Preencha o usuário e a senha.";
    $_SESSION["type"] = "danger";

    header("Location: " . BASEURL . "index.php");
    exit;
}

try {
    // 6. Conecta ao banco de dados.
    $db = open_database();

    // 7. Busca o usuário pelo login (sem comparar a senha na SQL).
    // O ? é um parâmetro que será preenchido de forma segura.
    $sql = "SELECT id, nome, user, password
            FROM usuarios
            WHERE user = ?
            LIMIT 1";
    $stmt = $db->prepare($sql);

    // 8. Associa o login ao parâmetro da consulta.
    $stmt->bind_param("s", $usuario);

    // 9. Executa a consulta.
    $stmt->execute();

    // 10. Obtém o resultado.
    $resultado = $stmt->get_result();
    $dados = $resultado->fetch_assoc();

    // 11. Verifica se o usuário existe e se a senha corresponde
    // ao hash armazenado no banco de dados.
    if ($dados && password_verify($senha, $dados["password"])) {
        // 12. Regenera o ID da sessão após o login,
        // para reduzir o risco de Session Fixation.
        session_regenerate_id(true);

        // 13. Armazena os dados do usuário na sessão.
        $_SESSION["id"] = $dados["id"];
        $_SESSION["nome"] = $dados["nome"];
        $_SESSION["user"] = $dados["user"];
        $_SESSION["is_admin"] = (strtolower($dados["user"]) === "admin");
        // Mensagem de sucesso.
        $_SESSION["message"] = "Bem vindo " . $dados["nome"] . "!";
        $_SESSION["type"] = "info";

        // 14. Fecha a consulta e a conexão.
        $stmt->close();
        close_database($db);

        // 15. Redireciona para a página inicial.
        header("Location: " . BASEURL . "index.php");
        exit;

    } else {
        // Usuário não encontrado ou senha incorreta.
        $_SESSION["message"] = "Usuário ou senha incorretos.";
        $_SESSION["type"] = "danger";

        $stmt->close();
        close_database($db);

        header("Location: " . BASEURL . "index.php");
        exit;
    }

} catch (Exception $e) {
    // Se ocorrer algum erro na conexão ou na consulta,
    // exibe uma mensagem genérica ao usuário.
    // O erro técnico não é exibido diretamente no site.
    $_SESSION["message"] = "Ocorreu um erro ao tentar realizar o login.";
    $_SESSION["type"] = "danger";

    // Registra o erro técnico no log do PHP para depuração.
    error_log("Erro no login: " . $e->getMessage());

    // Redireciona para a página inicial.
    header("Location: " . BASEURL . "index.php");
    exit;
}
?>

<!-- VERSÃO ANTIGA ANTES DE SER REESCRITA 
 < ?php
    // Esse é o valida.php
    include("../config.php");
    require_once(DBAPI);
    include(HEADER_TEMPLATE);

    // Verifica se houve POST e se o usuário ou a senha é(são) vazio(s)
    if (!empty($_POST) AND (empty($_POST['login']) OR empty($_POST['senha']))) {
        header('Location: ' . BASEURL . 'index.php');
        exit;
    }

    // Tenta se conectar a um banco de dados MySQL
    $db = open_database();

    try {
        // Selecionando o Banco de dados que está ajustado na constante DB_NAME
        // Caso ele não consiga,
        $db->select_db(DB_NAME);

        // Pegando o login e senha digitado no form
        $usuario = $_POST['login'];
        $senha = $_POST['senha'];

        // Testando para ver se o login e senha digitado no form não estão vazios
        if (!empty($usuario) && !empty($senha)) {

            // Pegando a senha digitada no form e criptografando ela para poder comparar
            // a função de criptografia FOI MOVIDA para o arquivo database.php (DBAPI)
            $senha = password_verify($usuario["'senha'"], PASSWORD_BCRYPT)

            // Validando o usuário/senha digitados
            $sql = "SELECT id, nome, user, password FROM usuarios WHERE (user = '" . $usuario . "') AND (password = '" . $senha . "') LIMIT 1";

            $query = $db->query($sql);

            if ($query->num_rows > 0) {
                // Coletando os dados
                $dados = $query->fetch_assoc();

                $id = $dados['id'];
                $nome = $dados['nome'];
                $user = $dados['user'];
                $password = $dados['password'];

                // Verifica se $user não está vazio
                if (!empty($user)) {
                    if (!isset($_SESSION)) session_start();

                    $_SESSION['message'] = "Bem vindo " . $nome . "!";
                    $_SESSION['type'] = "info";
                    $_SESSION['id'] = $id;
                    $_SESSION['nome'] = $nome;
                    $_SESSION['user'] = $user;

                } else {
                    // Mensagem de erro quando os dados são inválidos e/ou o usuário não foi encontrado
                    throw new Exception("Não foi possível se conectar!<br>Verifique seu usuário e senha.");
                }

                // Direciona para o index do site
                header("Location: " . BASEURL . "index.php");

            } else {
                // Mensagem de erro quando os dados são inválidos e/ou o usuário não foi encontrado
                throw new Exception("Não foi possível se conectar!<br>Verifique seu usuário e senha.");
            }

        } else {
            // Mensagem de erro quando os dados são inválidos e/ou o usuário não foi encontrado
            throw new Exception("Não foi possível se conectar!<br>Verifique seu usuário e senha.");
        }

    } catch (Exception $e) {
        $_SESSION['message'] = "Ocorreu um erro: " . $e->GetMessage();
        $_SESSION['type'] = "danger";
    }
?>

< ?php if (!empty($_SESSION['message'])) : ?>
    <div class="alert alert-< ?php echo $_SESSION['type']; ?> alert-dismissible" role="alert" id="actions">
        < ?php echo $_SESSION['message']; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    < ?php clear_messages(); ?>
< ?php endif; ?>

<header>
    <a href="< ?php echo BASEURL; ?>index.php" class="btn btn-light">
        <i class="fa-solid fa-rotate-left"></i> Voltar
    </a>
</header>

< ?php include(FOOTER_TEMPLATE); ?> -->