<?php
// Controle centralizado de permissões do sistema.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function usuario_logado() {
    return !empty($_SESSION['user']);
}

function usuario_admin() {
    return usuario_logado() && strtolower((string) $_SESSION['user']) === 'admin';
}

function exigir_login() {
    if (!usuario_logado()) {
        $_SESSION['message'] = 'Você precisa estar logado para realizar esta ação.';
        $_SESSION['type'] = 'warning';
        header('Location: ' . BASEURL . 'index.php');
        exit;
    }
}

function exigir_admin() {
    if (!usuario_admin()) {
        $_SESSION['message'] = usuario_logado()
            ? 'Apenas o administrador pode acessar esta área.'
            : 'Você precisa estar logado como administrador para acessar esta área.';
        $_SESSION['type'] = 'danger';
        header('Location: ' . BASEURL . 'index.php');
        exit;
    }
}

function exigir_escrita() {
    exigir_login();
}
?>
