<?php

// mysqli_report(MYSQLI_REPORT_STRICT);
$mysqli_driver = new mysqli_driver();
$mysqli_driver->report_mode = MYSQLI_REPORT_STRICT | MYSQLI_REPORT_ERROR;

function open_database()
{
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        $conn->set_charset("utf8");
        return $conn;
    } catch (Exception $e) {
        throw new Exception("Erro ao conectar no Banco de Dados:<br> {$e->getMessage()}");
        // $e->getMessage());
        //return null;
    }
}

function close_database($conn)
{
    try {
       // $conn = null/;
        $conn->close();
    } catch (Exception $e) {
       throw new Exception("Erro ao fechar no Banco de Dados:<br> {$e->getMessage()}");
    }
}


/**
 *  Pesquisa um Registro pelo ID em uma Tabela
 */
function find( $table = null, $id = null ) {
  
	$database = open_database();
	$found = null;

	try {
	  if ($id) {
	    $sql = "SELECT * FROM  $table WHERE id = $id";
	    $result = $database->query($sql);
	    
	    if ($result->num_rows > 0) {
	      $found = $result->fetch_assoc();
	    }
	    
	  } else {
	    
	    $sql = "SELECT * FROM $table";
	    $result = $database->query($sql);
	    
	    if ($result->num_rows > 0) {
	      //$found = $result->fetch_all(MYSQLI_ASSOC);
        
        /* Metodo alternativo*/
        $found = [];
        while ($row = $result->fetch_assoc()) {
          array_push($found, $row);
        } 
	    }
	  }
	} catch (Exception $e) {
	  $_SESSION['message'] = "Houve um erro:<br> {$e->getMessage()}";
	  $_SESSION['type'] = 'danger';
  }
	
	close_database($database);
	return $found;
}


/**
 *  Pesquisa Todos os Registros de uma Tabela
 */
function find_all( $table ) {
  return find($table);
}

function save($table = null, $data = null) {

  $database = open_database();

  $columns = null;
  $values = null;

  //print_r($data);

  foreach ($data as $key => $value) {
    $columns .= trim($key, "'") . ",";
    $values .= "'$value',";
  }

  // remove a ultima virgula
  $columns = rtrim($columns, ',');
  $values = rtrim($values, ',');

  $sql = "INSERT INTO  $table ($columns) VALUES ($values);";

  try {
    $database->query($sql);
    $_SESSION['message'] = "Registro cadastrado com sucesso.";
    $_SESSION['type'] = 'success';

  } catch (Exception $e) { 
    $_SESSION['message'] = "Nao foi possivel realizar a operação. <br> {$e->GetMessage()}";
    $_SESSION['type'] = "danger";
  } 

  close_database($database);

}

function update($table = null, $id = 0, $data = null)
{
  $database = open_database();
  $items = null;

  foreach($data as $key => $value){
    $items .= trim($key, "'") . "='$value',";
  }

  //remove a ultima virgula
  $items = rtrim($items, ",");

  // $sql = "UPDATE " . $table; 
  // $sql = "SET $items";
  // $sql = "WHERE id=" . $id . ";";
  // mesma coisa que isso aqui:
  $sql = "UPDATE  $table SET $items WHERE id= $id";


  try{
    $database->query($sql);
    $_SESSION["message"] = "Registro atualizado com sucesso.";
    $_SESSION['type'] = 'success';

  } catch (Exception $e) { 
    $_SESSION['message'] = "Nao foi possivel realizar a operação. <br> {$e->GetMessage()}";
    $_SESSION['type'] = "danger";
  } 
   
}

/* Remove uma linha de uma tabela pelo ID do registro */
function remove($table = null, $id = null)
{
  
  $database = open_database();

  try {
    if ($id) {
      $sql = "DELETE FROM $table  WHERE id = $id";
      //$result = $database->query($sql);
      
      if ($database->query($sql)){
        $_SESSION['message'] = "Registro removido com sucesso.";
        $_SESSION['type'] = 'success';
      }
    }
  } catch (Exception $e) {
    $_SESSION['message'] = "Houve um erro: <br> {$e ->getMessage()}";
      $_SESSION['type'] = 'danger';
  }
  
  close_database($database);

}

/**
 * Pesquisa registros pelo parametro $p que foi passado
 */
function filter($table = null, $p = null) {
    $database = open_database();
    $found = null;

    try {
        if ($p) {
            $sql = "SELECT * FROM  . $table .  WHERE  . $p";
            $result = $database->query($sql);

            if ($result->num_rows > 0) {
              // $found = $result->fetch_all(MYSQL_ASSOC);
              // ou, método alternativo:
                $found = array(); // ou $found = [];

                while ($row = $result->fetch_assoc()) {
                    array_push($found, $row);
                }
            } else {
                throw new Exception("Não foram encontrados registros de dados!");
            }
        }
    } catch (Exception $e) {
        $_SESSION['message'] = "Ocorreu um erro: " . $e->GetMessage();
        $_SESSION['type'] = "danger";
    }

    close_database($database);
    return $found;
}

function clear_messages() {
    $_SESSION['message'] = null;
    $_SESSION['type'] = null;
}

/**
 * Criptografia
 */
function criptografia($senha){
    /*
        ==> Criptografia Blowfish
        http://www.linhadecodigo.com.br/artigo/3532/criptografando-senhas-usando-bcrypt-blowfish-no-php.aspx
    */

    // Aplicando criptografia na senha
    $custo = "08";
    $salt = "Cflf1lePArK1BJomMOF6éaJd";

    // Gera um hash baseado em bcrypt
    $hash = crypt($senha, "$2a$" . $custo . "$" . $salt . "$");

    return $hash; // retorna a senha criptografada
}
