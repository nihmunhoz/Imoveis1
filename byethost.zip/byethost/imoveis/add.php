<?php 
  require_once('functions.php'); 
  add();
?>

<?php include(HEADER_TEMPLATE); ?>

<h2>Novo imóvel</h2>

<form action="add.php" method="post" enctype="multipart/form-data">
  <!-- area de bla bla bla -->
 <hr>
  <div class="row mt-2">
    <div class="form-group col-md-5">
      <label for="name">Nome do imóvel</label>
      <input type="text" class="form-control" id="name" name="imovel['nome']" maxlength="100">
    </div>

    <div class="form-group col-md-5">
      <label for="proprietario">Proprietário</label>
      <input type="text" class="form-control" id="proprietario" name="imovel['proprietario']" maxlength="50">
    </div>

    <div class="form-group col-md-2">
      <label for="preco">Preço</label>
      <input type="text" class="form-control" id="preco" name="imovel['preco']">
    </div>
 
  </div>
  
  <div class="row mt-2">

    <div class="form-group col-md-5">
      <label for="endereco">Endereço</label>
      <input type="text" class="form-control" id="endereco" name="imovel['endereco']" maxlength="50">
    </div>

    <div class="form-group col-md-5">
      <label for="cidade">Cidade</label>
      <input type="text" class="form-control" id="cidade" name="imovel['cidade']" maxlength="100">
    </div>

    <div class="form-group col-md-2">
      <label for="estado">Estado</label>
      <input type="text" class="form-control" id="estado" name="imovel['estado']" maxlength="2">
    </div>

  </div>
    
  <div class="row mt-2">

    <div class="form-group col-md-6">
      <label for="descricao">Descrição</label>
      <input type="text" class="form-control" id="descricao" name="imovel['descricao']" maxlength="150">
    </div>

    <div class="form-group col-md-6">
          <label for="foto">Foto do imóvel</label>
          <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
      </div>

  </div>

  
  <div id="actions" class="row mt-4">
    <div class="col-md-12">
      <button type="submit" class="btn btn-regiao"> <i class="fa-solid fa-floppy-disk"></i> Salvar</button>
      <a href="index.php" class="btn btn-can"> <i class="fa-solid fa-rotate-left"></i> Cancelar</a>
    </div>
  </div>
</form>
    
<?php include (FOOTER_TEMPLATE);?>