<?php
    include "functions.php";
    index();
 	include HEADER_TEMPLATE; ?>

<style>
	.foto-tabela{
		width: 130px;
		border-radius: 5px;
		box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
		object-fit: cover;
	}

	.alinha{
		text-align: center;
	}

	.margem-botao{
		margin: 2px;
	}
</style>

<header>
	<div class="row">
		<div class="col-sm-6">
			<h2>Imóveis</h2>
		</div>
		<div class="col-sm-6 text-end h2">
	    	<?php if (usuario_logado()) : ?><a class="btn btn-azul" href="add.php"><i class="fa-solid fa-plus"></i> Novo imovel</a><?php endif; ?>
	    	<a class="btn btn-atu" href="index.php"><i class="fa fa-refresh"></i> Atualizar</a>
	    </div>
	</div>
	
</header>

<?php if (!empty($_SESSION['message'])) : ?>
	<div class="alert alert-<?php echo $_SESSION['type']; ?> alert-dismissible" role="alert">
		<button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<?php echo $_SESSION['message']; ?>
	</div>
<?php //clear_messages(); ?>
<?php endif; ?>

<hr>

<table class="table table-hover">
	<thead>
		<tr>
			<th class="alinha">ID</th>
			<th class="alinha some">Foto</th>
			<th class="alinha">Nome</th>
			<th class="alinha some">Preço</th>		
			<th class="alinha some">Criado em</th>
			<th class="alinha some">Atualizado em</th>
			<th class="alinha">Opções</th>
		</tr>
	</thead>

	<tbody>
		<?php if ($imoveis) : ?>
		<?php foreach ($imoveis as $imovel) : ?>
			<tr>
				<td class="alinha"><?= $imovel['id']; ?></td>

				<td class="alinha some"><a href="view.php?id=<?php echo $imovel['id']; ?>"><img class="foto-tabela" src="../img/<?php echo $imovel['foto']; ?>"></a></td>
				<td class="alinha"><?php echo $imovel['nome']; ?></td>
				<td class="alinha some"><?= dinheiro($imovel['preco']); ?></td>
				
				<td class="alinha some">
					<?php  	$dt = new DateTime($imovel['created'], new DateTimeZone("-0300")); // ou America/Sao_Paulo
							echo $dt-> format("d/m/Y - H:i:s"); ?>
				</td>
				
				<td class="alinha some quase-some">
					<?php  $dt = new DateTime($imovel['modified'], new DateTimeZone("-0300")); // ou America/Sao_Paulo
						echo $dt-> format("d/m/Y - H:i:s"); ?>
				</td>
				<td class="actions text-end">

					<a href="view.php?id=<?php echo $imovel['id']; ?>" class="btn-opcoes btn btn-sm btn-vizu">
						<i class="fa-solid fa-eye"></i>
						Visualizar
					</a>

					<?php if (usuario_logado()) : ?>
					<a href="edit.php?id=<?php echo $imovel['id']; ?>" class="btn-opcoes btn btn-sm btn-azul">
						<i class="fa-solid fa-pencil"></i>
						Editar
					</a>

					<!-- ANTES <a href="#" class="btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#delete-modal-imovel" data-imovel="<?php echo $imovel['id']; ?>">
						<i class="fa-solid fa-trash-can"></i>
						Excluir
					</a> -->

					<a href="delete.php?id=<?php echo $imovel['id']; ?>" class="btn-opcoes btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#delete-modal-imovel" data-delete-url="delete.php?id=<?php echo $imovel['id']; ?>">
						<i class="fa-solid fa-trash-can"></i>
						Excluir
					</a>
					<?php endif; ?>

				</td>
			</tr>
		<?php endforeach; ?>
		<?php else: ?>
			<tr>
				<td colspan="6">Nenhum registro encontrado.</td>
			</tr>
		<?php endif; ?>
	</tbody>
</table>

<?php 
include "modal.php";
include FOOTER_TEMPLATE;
?>