<?php 
	include "functions.php"; 
	view($_GET['id']);

    include HEADER_TEMPLATE; ?>

<h2><?=$imovel['nome']; ?> (ID: <?php echo $imovel['id']; ?>)</h2>
<hr>

<?php if (!empty($_SESSION['message'])) : ?>
	<div class="alert alert-<?php echo $_SESSION['type']; ?>">
		<?php echo $_SESSION['message']; ?></div>
<?php endif; ?>

<style>
	.view-foto{
		width: 100%;
		max-width: 550px;
		float: right;
		margin: 5px;
		height: auto;
		border-radius: 5px;
		object-fit: cover;
	}
</style>

<div class="row">
	<div class="col-md-6">
		<div class="row">

			<div class="col-md-6">
				<dl class="dl-horizontal">
					<dt class="mt-2">Nome</dt>
					<dd><?php echo $imovel['nome']; ?></dd>
				
					<dt class="mt-4">Cidade</dt>
					<dd><?php echo $imovel['cidade']; ?></dd>

					<dt class="mt-4">Endereço</dt>
					<dd><?php echo $imovel['endereco']; ?></dd>
				</dl>
			</div>

			<div class="col-md-6">
				<dl class="dl-horizontal">
					<dt class="mt-2">Preço</dt>
					<dd><?php echo dinheiro($imovel['preco']); ?></dd>

					<dt class="mt-4">Estado</dt>
					<dd><?php echo $imovel['estado']; ?></dd>

					<dt class="mt-4">Proprietário</dt>
					<dd><?php echo $imovel['proprietario']; ?></dd>
				</dl>
			</div>

		</div>

		<div class="row">
			<div class="col-md-12">
				<dt class="mt-2">Descrição</dt>
				<dd><?php echo $imovel['descricao']; ?></dd>
			</div>
		</div>
					
		<div class="row mt-4">
			<div class="col-md-6">
				<dl class="dl-horizontal">
					<dt class="mt-2">Data de Cadastro</dt>
					<dd><?php echo formataData($imovel['created'], "d/m/Y - H:i:s"); ?></dd>
				</dl>
			</div>

			<div class="col-md-6 ">
				<dl class="dl-horizontal">
					<dt class="mt-2">Data da última alteração</dt>
					<dd><?php echo formataData($imovel['modified'], "d/m/Y - H:i:s"); ?></dd>
				</dl>
			</div>
		</div>	
	</div>

	<div class="col-md-6">
		<a href="../img/<?php echo $imovel['foto']; ?>" data-lightbox="foto">
			<img class="view-foto" src="../img/<?php echo $imovel['foto']; ?>">
		</a>
	</div>

</div>
	

	


	
</div>

<div id="actions" class="row">
	<div class="col-md-12">
	  <?php if (usuario_logado()) : ?>
	  <a href="edit.php?id=<?php echo $imovel['id']; ?>" class="btn btn-secondary"> 
		<i class="fa-solid fa-pencil"></i> Editar</a>
	  <?php endif; ?>
	  <a href="index.php" class="btn btn-light">
		<i class="fa-solid fa-arrow-rotate-left"></i> Voltar
	</a>
	</div>
</div>

<?php include(FOOTER_TEMPLATE); ?>