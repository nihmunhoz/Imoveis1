<?php

ob_start();
include "../config.php";
require_once ABSPATH . "inc/permissoes.php";
include DBAPI;

$imoveis = null;
$imovel = null;

/**
 *  Listagem de imoveis
 */
function index() {
	global $imoveis;
	$imoveis = find_all("imoveis");
}

/**
 *  Formata as datas
 */
function formataData($data, $formato) 
{
  $dt = new DateTime($data, new DateTimeZone("-0300"));
  return $dt->format($formato);
}

/*Formatar o preco*/ 
function dinheiro($preco)  /* R$000.000.000,00 */
{
  $preco = number_format($preco, 2);
  $preco = str_replace(".", "a", $preco); $preco = str_replace(",", "b", $preco);
  $preco = str_replace("a", ",", $preco); $preco = str_replace("b", ".", $preco);
  return "R$" . $preco ; 
}

/* Formatar o CPF */ 
function cpf($CPF) /* 123.456.789-00 ou 12.345.678.9012-34*/ 
{
  if (mb_strlen($CPF, 'UTF-8') <= 11){ //se for cpf
    return substr($CPF,0,3). "." . substr($CPF,3,3) . "." . substr($CPF,6,3) . "-" . substr($CPF,9,2);
  } else { //se for cnpj
    return substr($CPF,0,2). "." . substr($CPF,2,3) . "." . substr($CPF,5,3) . "/" . substr($CPF,8,4) . "-" . substr($CPF,12,2);
  }
}
function cep($CEP) /* 12345-67 */ 
{
  return substr($CEP,0,5). "-" . substr($CEP,5,3) ;
}

function view($id = null) {
  global $imovel;
  $imovel = find("imoveis", $id);
}

/*  Cadastro de Clientes */
function add()
{
  exigir_escrita();
  {
    if (!empty($_POST["imovel"])) {
      
      $today = date_create("now", new DateTimeZone("America/Sao_Paulo"));  // ou ("-0300)

      $imovel = $_POST["imovel"];
      $imovel["modified"] = $imovel["created"] = $today->format("Y-m-d H:i:s");
      $imovel["foto"] = uploadFoto();
      
      save("imoveis", $imovel);
      header("location: index.php");
    }
  } 
}


function edit()
{
  exigir_escrita();
  $now = new DateTime("now", new DateTimeZone("-0300"));

  if (isset($_GET['id'])) {

      $id = $_GET['id'];

      if (isset($_POST['imovel'])) {

        $imovel = $_POST['imovel'];
        $imovel['modified'] = $now->format('Y-m-d H:i:s');
        // Só troca a foto se o usuário escolher uma nova
        if (!empty($_FILES['foto']['name'])) {
            $imovel['foto'] = uploadFoto();
        }

        update("imoveis", $id, $imovel);
        header("location: index.php");

      } else {
        global $imovel;
        $imovel = find("imoveis", $id);
      }

  } else {
    header("location: index.php");
  }
}

function delete($id = null) {
  exigir_escrita();

  global $imovel;
  $imovel = remove('imoveis', $id);

  header('location: index.php');
}

/* Função para lidar com upload de imagens */
function uploadFoto()
{
    if (empty($_FILES['foto']['name'])) {
        return "sem-imagem.png";
    }

    $arquivo = $_FILES['foto'];

    if ($arquivo['error'] !== UPLOAD_ERR_OK) {
        return "sem-imagem.png";
    }

    $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    $tipo = mime_content_type($arquivo['tmp_name']);

    if (!in_array($tipo, $tiposPermitidos)) {
        return "sem-imagem.png";
    }

    $extensoes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp'
    ];

    $extensao = $extensoes[$tipo];

    $nomeArquivo = uniqid('imovel_') . '.' . $extensao;

    $pasta = "../img/imoveis/";

    if (!is_dir($pasta)) {
        mkdir($pasta, 0777, true);
    }

    move_uploaded_file(
        $arquivo['tmp_name'],
        $pasta . $nomeArquivo
    );

    return "imoveis/" . $nomeArquivo;
}