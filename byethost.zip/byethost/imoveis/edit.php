<?php 
  require_once('functions.php'); 
  edit();
  include(HEADER_TEMPLATE);
?>

<h2>Atualizar imóvel</h2>

<form action="edit.php?id=<?php echo $imovel['id']; ?>" method="post" enctype="multipart/form-data">
  <!-- area de campos do form -->
  <hr/>
  <div class="row mt-2">
    <div class="form-group col-md-5">
      <label for="name">Nome do imóvel</label>
      <input type="text" class="form-control" id="name" name="imovel['nome']" maxlength="100"
      value="<?php echo $imovel['nome'];?>">
    </div>

    <div class="form-group col-md-5">
      <label for="proprietario">Proprietário</label>
      <input type="text" class="form-control" id="proprietario" name="imovel['proprietario']" maxlength="50"
      value="<?php echo $imovel['proprietario'];?>">
    </div>

    <div class="form-group col-md-2">
      <label for="preco">Preço</label>
      <input type="text" class="form-control" id="preco" name="imovel['preco']"
      value="<?php echo $imovel['preco'];?>">  
    </div>
 
  </div>
  
  <div class="row mt-2">

    <div class="form-group col-md-5">
      <label for="endereco">Endereço</label>
      <input type="text" class="form-control" id="endereco" name="imovel['endereco']" maxlength="50"
      value="<?php echo $imovel['endereco'];?>">
    </div>

    <div class="form-group col-md-5">
      <label for="cidade">Cidade</label>
      <input type="text" class="form-control" id="cidade" name="imovel['cidade']" maxlength="100"
      value="<?php echo $imovel['cidade'];?>">
    </div>

    <div class="form-group col-md-2">
      <label for="estado">Estado</label>
      <input type="text" class="form-control" id="estado" name="imovel['estado']" maxlength="2"
      value="<?php echo $imovel['estado'];?>">
    </div>

  </div>
    
  <div class="row mt-2">

    <div class="form-group col-md-6">
      <label for="descricao">Descrição</label>
      <input type="text" class="form-control" id="descricao" name="imovel['descricao']" maxlength="150"
      value="<?php echo $imovel['descricao'];?>">
    </div>

    <div class="form-group col-md-6">
        <label for="foto">Foto do imóvel</label>
        <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
    </div>

    <!--<div class="form-group col-md-2">
      <label for="imovel['created']">Data de Cadastro</label>
      <input type="text" class="form-control" id="imovel" name="imovel['created']" disabled
      value="<?php echo $imovel['created'];?>">
    </div> -->

  </div>

  <div class="row mt-2">
    
  </div>
      
  
  <div id="actions" class="row mt-4">
    <div class="col-md-12">
      <button type="submit" class="btn btn-secondary"> <i class="fa-solid fa-floppy-disk"></i> Salvar</button>
      <a href="index.php" class="btn btn-light"> <i class="fa-solid fa-rotate-left"></i> Cancelar</a>
    </div>
  </div>
</form>
    
<?php include (FOOTER_TEMPLATE);?>