<?php
include "functions.php";

if (isset($_GET['id'])) {
    try {
        // Busca os dados antes da exclusão para obter o nome da foto.
        $usuario = find("usuarios", $_GET['id']);

        // A função delete() também verifica se o usuário é administrador.
        delete($_GET['id']);

        // Remove somente fotos próprias do usuário; preserva a imagem padrão.
        if (!empty($usuario['foto']) && $usuario['foto'] !== 'sem-imagem.png') {
            $caminhoFoto = __DIR__ . "/foto/" . basename($usuario['foto']);
            if (is_file($caminhoFoto)) {
                unlink($caminhoFoto);
            }
        }
    } catch (Exception $e) {
        $_SESSION['message'] = "Não foi possível realizar a operação: " . $e->getMessage();
        $_SESSION['type'] = "danger";
        header("Location: index.php");
        exit;
    }
} else {
    $_SESSION['message'] = "ERRO: ID não definido!";
    $_SESSION['type'] = "danger";
    header("Location: index.php");
    exit;
}
?>
