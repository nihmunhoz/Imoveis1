<?php
//esse é o edit.php

include("functions.php");
edit();
include(HEADER_TEMPLATE);
?>

<header>
    <h2>Atualizar Usuário</h2>
</header>

<form action="edit.php?id=<?php echo $usuario['id']; ?>" method="post" enctype="multipart/form-data">
    <!-- area de campos do form -->
    <hr>
    <div class="row">
        <div class="col-md-6">

            <div class="form-group col-md-12">
                <label for="name">Nome</label>
                <input type="text" class="form-control" id="name" name="usuario['nome']" value="<?php echo $usuario['nome']; ?>" maxlength="50">
            </div>

            <div class="form-group col-md-12">
                <label for="login">Usuário (Login)</label>
                <input type="text" class="form-control" id="login" name="usuario['user']" value="<?php echo $usuario['user']; ?>" maxlength="50">
            </div>
              
            <div class="form-group col-md-12">
                <label for="senha">Senha</label>
                <input type="password" class="form-control" id="senha" name="usuario['password']" value="<?= $usuario['foto'] ?>">
            </div>
           
            <?php
                $foto = "";

                if (empty($usuario['foto'])){
                    $foto = "sem-imagem.png";
                } else {
                    $foto = $usuario['foto'];
                }
            ?>

            <div class="form-group col-md-12">
                <label for="campo1">Foto</label>
                <input type="file" class="form-control" id="foto" name="foto" value="foto/<?php echo $foto ?>">
            </div>
         
        </div>

        <div class="col-md-6">
            <div class="form-group col-md-6">
                <label for="pre">Pré-visualização:</label>
                <img class="form-control img-thumbnail view-img" id="imgPreview" src="foto/<?php echo $foto ?>" alt="Foto do usuário">
            </div> 
        </div>

    </div>

    <div id="actions" class="row">
        <div class="col-md-12">
            <button type="submit" class="btn btn-secondary"><i class="fa-solid fa-sd-card"></i> Salvar</button>
            <a href="index.php" class="btn btn-light"><i class="fa-solid fa-rotate-left"></i> Cancelar</a>
        </div>
    </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>

<script>
    $(document).ready(() => {
        $("#foto").change(function () {
            const file = this.files[0];

            if (file) {
                let reader = new FileReader();

                reader.onload = function (event) {
                    $("#imgPreview").attr("src", event.target.result);
                };

                reader.readAsDataURL(file);
            }
        });
    });
</script>