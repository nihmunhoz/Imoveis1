<?php
//esse é o functions.php

require_once('../config.php');
require_once ABSPATH . 'inc/permissoes.php';
require_once(DBAPI);

$usuario = null;
$usuarios = null;

/**
 * Listagem de Usuários
 */
function index() {
    exigir_admin();
    global $usuarios;

    if (!empty($_POST['users'])){
        $usuarios = filter("usuarios", "nome like '%" . $_POST['users'] . "%'");
    } else {
        $usuarios = find_all("usuarios");
    }
}


/**
 * Upload de imagens
 */
function upload($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo){
    /*
        ==> Upload de arquivos no PHP
        https://www.w3schools.com/php/php_file_upload.asp
    */

    // Upload da foto
    try {
        $nomearquivo = basename($arquivo_destino); // nome do arquivo
        $uploadOk = 1;

        // Verificando se o arquivo é uma imagem
        if (isset($_POST["submit"])) {
            $check = getimagesize($nome_temp);

            if ($check !== false) {
                $_SESSION['message'] = "File is an image - " . $check["mime"] . ".";
                $_SESSION['type'] = "info";
                //echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                $uploadOk = 0;
                throw new Exception("O arquivo não é uma imagem!");
                //echo "O arquivo não é uma imagem!";
            }
        }

        // Verificando se o arquivo já existe na pasta
        if (file_exists($arquivo_destino)) {
            $uploadOk = 0;
            throw new Exception("Desculpe, o arquivo já existe!");
            //echo "Desculpe, o arquivo já existe.";
        }

        // Verificando se o tamanho do arquivo
        if ($tamanho_arquivo > 5000000) {
            $uploadOk = 0;
            throw new Exception("Desculpe, mas o arquivo é muito grande!");
            //echo "Desculpe, mas o arquivo é muito grande!";
        }

        // Allow certain file formats
        if ($tipo_arquivo != "jpg" && $tipo_arquivo != "png" && $tipo_arquivo != "jpeg"
            && $tipo_arquivo != "gif") {
            $uploadOk = 0;
            throw new Exception("Desculpe, mas só são permitidos arquivos de imagem JPG, JPEG, PNG e GIF!");
            //echo "Desculpe, mas só são permitidos arquivos de imagem JPG, JPEG, PNG e GIF!";
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            throw new Exception("Desculpe, mas o arquivo não pode ser enviado.");
            //echo "Desculpe, mas o arquivo não pode ser enviado.";
        } else {
            // Se tudo estiver OK, tentamos fazer o upload do arquivo
            if (move_uploaded_file($_FILES["foto"]["tmp_name"], $arquivo_destino)) {
                //colocando o nome do arquivo da foto do usuário no vetor
                $_SESSION['message'] = "O arquivo " . htmlspecialchars($nomearquivo) . " foi armazenado.";
                $_SESSION['type'] = "success";
                //echo "The file " . htmlspecialchars(basename($_FILES["fileToUpload"]["name"])) . " has been uploaded.";
            } else {
                throw new Exception("Desculpe, mas o arquivo não pode ser enviado.");
                //echo "Sorry, there was an error uploading your file.";
            }
        }
    } catch (Exception $e) {
        $_SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
        $_SESSION['type'] = "danger";
    }
}
/**
 * Cadastro de Usuários
 */
function add()
{
    exigir_admin();

    try {
        if (!empty($_POST["usuario"])) { // <<== Nome do vetor HTML

            $user = $_POST['usuario'];

            // Criptografando a senha
            $user["'password'"] = password_hash($user["'password'"], PASSWORD_BCRYPT);
            // Lembre-se de usar password_verify() no ==> valida.php

            $caminho = "foto/";
            $arquivo = basename($_FILES["imagem"]["name"]);
            $destino = $caminho . $arquivo;
            
            if (move_uploaded_file($_FILES["imagem"]["tmp_name"],$destino)) {
                $_SESSION['message'] = $_SESSION['message'] . "Imagem foi gravada!";
                $_SESSION['type'] = 'info';
            } else {
                $_SESSION['message'] = $_SESSION['message'] . "Imagem não foi gravada!";
                $_SESSION['type'] = 'danger';
            }

            $user["'foto'"] = $arquivo;

            save("usuarios", $user);
            header("location: index.php");
        }
    } catch (Exception $e) {  
        throw new Exception("Aconteceu um erro ao gravar!");
    }}


/**
 * Atualizacao/Edicao de Usuários
 */
function edit() {
    exigir_admin();
    // $now = new DateTime("now");
    try {
        if (isset($_GET['id'])) {

            $id = $_GET['id'];
            
            if (isset($_POST['usuario'])) {

                $usuario = $_POST['usuario'];

                //criptografando a senha
                if (!empty($usuario['password'])){
                    $senha = criptografia($usuario['password']);
                    $usuario['password'] = $senha;
                }

                if (!empty($_FILES["foto"]["name"])) {
                    // Upload da foto
                    $pasta_destino = "foto/"; //pasta onde ficam as fotos

                    $arquivo_destino = $pasta_destino . basename($_FILES["foto"]["name"]); //Caminho completo até o arquivo que será gravado
                    $nomearquivo = basename($_FILES["foto"]["name"]); // nome do arquivo
                    $resolucao_arquivo = getimagesize($_FILES["foto"]["tmp_name"]);
                    $tamanho_arquivo = $_FILES["foto"]["size"]; //tamanho do arquivo em bytes
                    $nome_temp = $_FILES["foto"]["tmp_name"];// nome e caminho do arquivo no servidor
                    $tipo_arquivo = strtolower(pathinfo($arquivo_destino, PATHINFO_EXTENSION));// extensão do arquivo

                    upload($pasta_destino, $arquivo_destino, $tipo_arquivo, $nome_temp, $tamanho_arquivo);

                    $usuario['foto'] = $nomearquivo;
                }

                update('usuarios', $id, $usuario);
                header('Location: index.php');

            } else {
                global $usuario;
                $usuario = find("usuarios", $id);
            }

        } else {
            header("Location: index.php");
        }

    } catch (Exception $e) {
        $_SESSION['message'] = "Aconteceu um erro: " . $e->getMessage();
        $_SESSION['type'] = "danger";
    }
}

/**
 * Visualização de um Usuários
 */
function view($id = null) {
    exigir_admin();
    global $usuario;
    $usuario = find("usuarios", $id);
}

/**
 * Exclusão de um Usuários
 */
function delete($id = null) {
    exigir_admin();

    global $usuarios;
    $usuarios = remove("usuarios", $id);

    header("Location: index.php");
}
?>