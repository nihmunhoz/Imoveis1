<?php
include "functions.php";
add();
include HEADER_TEMPLATE;
?>

<h2>Novo Usuário</h2>

<form action="add.php" method="post" enctype="multipart/form-data">
    <!-- area de campos do form -->
    <hr>

    <div class="row">
        <div class="col-md-6">
            
            <div class="form-group col-md-12">
                <label for="name">Nome</label>
                <input type="text" class="form-control" id="name" name="usuario['nome']" maxlength="50">
            </div>
        
            <div class="form-group col-md-12">
                <label for="login">Usuário (Login)</label>
                <input type="text" class="form-control" id="login" name="usuario['user']" maxlength="50">
            </div>
            
            <div class="form-group col-md-12">
                <label for="senha">Senha</label>
                <input type="password" class="form-control" id="senha" name="usuario['password']" value="">
            </div>

        
            <div class="form-group col-md-12">
                <label for="campo1">Foto</label>
                <input type="file" class="form-control" id="foto" name="imagem" accept="image/*">
            </div>
         
        </div>

        <div class="col-md-6">
            <div class="form-group col-md-6">
                <label for="pre">Pré-visualização:</label>
                  <?php
                    $foto = BASEURL . "usuarios/foto/sem-imagem.png";
                    if (!empty($usuario['foto'])){
                        $foto = BASEURL . "usuarios/foto/" . $usuario["foto"];
                    }
                ?>
                <img class="form-control img-thumbnail view-img" src="<?= $foto ?>" id="preview" alt="Foto do usuário">
            </div> 
        </div>

        
    </div>

    <div id="actions" class="row mt-2">
        <div class="col-md-12">
            <button type="submit" class="btn btn-secondary"><i class="fa-solid fa-floppy-disk"></i> Salvar</button>
            <a href="index.php" class="btn btn-light"><i class="fa-solid fa-rotate-left"></i> Cancelar</a>
        </div>
    </div>
</form>

<?php include FOOTER_TEMPLATE; ?>
<script>
    const input = document.getElementById('foto');
    const preview = document.getElementById('preview');

    input.addEventListener('change', function (event) {
        const arquivo = event.target.files[0];

        if (arquivo) {
            preview.src = URL.createObjectURL(arquivo);
            preview.onload = () => {
                URL.revokeObjectURL(preview.src); // Libera a memória após carregar
            };
        }
    });

</script>