<!-- modal de deletar -- EDITAR de acordo com o ID e classes usados na aula do LF, dia 02/09/2026 -->

<!-- 
Button trigger modal :

<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
  Launch static backdrop modal
</button>
-->

<!-- Modal -->
<div class="modal fade" id="delete-user-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title fs-5" id="ModalLabel">Excluir usuário</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Deseja realmente excluir esse usuário?
      </div>
      <div class="modal-footer">
        <a id="confirm" class="btn btn-dark" href="#"><i class="fa-solid fa-trash-can"></i> Sim</a>
        <a id="cancel" class="btn btn-secondary" data-bs-dismiss="modal"> <i class="fa-solid fa-rotate-left"></i> Não</a>
      </div>
    </div>
  </div>
</div>