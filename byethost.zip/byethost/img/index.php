<?php
    include("../config.php");
    include(DBAPI);
?>

<?php include(HEADER_TEMPLATE); 

$dir_iterator = new RecursiveDirectoryIterator(__DIR__);
$iterator = new RecursiveIteratorIterator(
    $dir_iterator,
    RecursiveIteratorIterator::SELF_FIRST
);

$files = [];

foreach ($iterator as $file) {
    if ($file->isFile()){
        $extensao = strtolower($file->getExtension());
        $extensoesPermitidas = [ 'jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($extensao, $extensoesPermitidas)) {
            $files[] = $file;
        }
    }
}
?>

<style>
    .galeria {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: flex-start;
    }

    .galeria a {
        display: block;
    }

    .galeria img {
        width: 180px;
        height: 140px;
        object-fit: cover;
        display: block;
        border-radius: 5px;
        box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.12);
    }
</style>

<header>
    <div class="row col-sm-6">
        <h2>Galeria</h2>
    </div>
</header>
<hr>


<div class="galeria">

    <?php foreach ($files as $file) : ?>
        <?php
            $nomeArquivo = $file->getFilename();
            $caminho = str_replace(
                __DIR__ . DIRECTORY_SEPARATOR,
                '',
                $file->getPathname()
            );

            $caminho = str_replace(
                DIRECTORY_SEPARATOR,
                '/',
                $caminho
            );
        ?>

        <a href="<?php echo htmlspecialchars($caminho); ?>" data-lightbox="galeria" data-title="<?php echo htmlspecialchars($nomeArquivo); ?>">
            <img src="<?php echo htmlspecialchars($caminho); ?>" alt="<?php echo htmlspecialchars($nomeArquivo); ?>" >
        </a>

    <?php endforeach; ?>

</div>

<?php include(FOOTER_TEMPLATE); ?>