<?php

// /** O nome do banco de dados*/
// //define('DB_NAME', 'wda_crud');
// const DB_NAME = "wda_crud";

// /** Usuário do banco de dados MySQL */
// define("DB_USER", "root");

// /** Senha do banco de dados MySQL */
// define('DB_PASSWORD', '');

// /** nome do host do MySQL */
// define('DB_HOST', 'localhost');

// /** caminho absoluto para a pasta do sistema **/
// if (!defined('ABSPATH'))
//     define('ABSPATH', dirname(__FILE__) . '/');

// /** caminho no server para o sistema **/
// if (!defined('BASEURL'))
//     define('BASEURL', '/crud-bootstrap-php/');

// /** caminho do arquivo de banco de dados **/
// if (!defined('DBAPI'))
//     define('DBAPI', ABSPATH . 'inc/database.php');
	
// /** caminhos dos templates de header e footer **/
// define('HEADER_TEMPLATE', ABSPATH . 'inc/header.php');
// define('FOOTER_TEMPLATE', ABSPATH . 'inc/footer.php');

/* para usar hospedado: (retirar comentários: ctrl + ;)*/

// O nome do banco de dados
define('DB_NAME', 'b7_42993170_wda_crud');
const DB_NAME = "b7_42993170_wda_crud";

/** Usuário do banco de dados MySQL */
define("DB_USER", "b7_42993170");

/** Senha do banco de dados MySQL */
define('DB_PASSWORD', 'ABC_2009@pato!');

/** nome do host do MySQL */
define('DB_HOST', 'sql208.byethost7.com');

/** caminho absoluto para a pasta do sistema **/
if (!defined('ABSPATH'))
    define('ABSPATH', dirname(__FILE__) . '/');

/** caminho no server para o sistema **/
if (!defined('BASEURL'))
    define('BASEURL', '/');

/** caminho do arquivo de banco de dados **/
if (!defined('DBAPI'))
    define('DBAPI', ABSPATH . 'inc/database.php');
	
/** caminhos dos templates de header e footer **/
define('HEADER_TEMPLATE', ABSPATH . 'inc/header.php');
define('FOOTER_TEMPLATE', ABSPATH . 'inc/footer.php');


