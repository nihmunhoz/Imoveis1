-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25/11/2026 às 00:22
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "-03:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `wda_crud`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `cpf_cnpj` varchar(15) NOT NULL,
  `birthdate` datetime NOT NULL,
  `address` varchar(255) NOT NULL,
  `hood` varchar(100) NOT NULL,
  `zip_code` varchar(8) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(2) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `ie` varchar(15) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `customers`
--

INSERT INTO `customers` (`id`, `name`, `cpf_cnpj`, `birthdate`, `address`, `hood`, `zip_code`, `city`, `state`, `phone`, `mobile`, `ie`, `created`, `modified`) VALUES
(1, 'Fulano de Tal', '12345678900', '0000-00-00 00:00:00', 'Rua da Web, 123', 'Internet', '12345678', 'Teste', 'Te', '1512345678', '15987654321', '123456', '2016-05-24 00:00:00', '2026-09-08 17:28:52'),
(2, 'Ciclano de Tal', '123.456.789-00', '1989-01-01 00:00:00', 'Rua da Web, 123', 'Internet', '12345678', 'Teste', 'Te', '15 12345678', '15987654321', '123456', '2016-05-24 00:00:00', '2016-05-24 00:00:00'),
(6, 'Cliente', '12345678911', '1814-09-06 00:00:00', 'Rua Tananana Numero TamTanan', 'Bairro Bairro Bairro', '12312312', 'Sorocaba', 'SP', '55159999999', '55159999999', '123123', '2026-09-08 10:55:18', '2026-09-08 18:00:50'),
(9, 'Clenton', '234567801234567', '0222-02-22 00:00:00', 'Rua 3 casa 4', 'Bairro 2', '12345678', 'Rio de Janeiro', 'RJ', '11978654234', '99999999999', '111111111111111', '2026-09-08 17:50:01', '2026-09-08 17:56:30');

-- --------------------------------------------------------

--
-- Estrutura para tabela `imoveis`
--

CREATE TABLE `imoveis` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `endereco` varchar(50) NOT NULL,
  `descricao` varchar(150) NOT NULL DEFAULT 'Esse imóvel ainda não possui uma descrição.',
  `proprietario` varchar(50) NOT NULL,
  `foto` varchar(150) DEFAULT 'sem-imagem.png',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `estado` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `imoveis`
--

INSERT INTO `imoveis` (`id`, `nome`, `endereco`, `descricao`, `proprietario`, `foto`, `created`, `modified`, `preco`, `cidade`, `estado`) VALUES
(1, 'Apartamento pequeno', 'Rua José Ferreira Silva, 14', 'Apartamento pequeno em São Paulo!!', 'José Silva Ferreira', 'imoveis/imovel_6ab2ea656af4d.jpg', '2026-09-22 12:48:06', '2026-09-22 18:23:57', 1500.00, 'São Paulo', 'SP'),
(2, 'Casa Engraçada', 'Rua dos bobos, 0', '', 'Vinicius', 'imoveis/imovel_6ab2eb264d01d.jpg', '2026-09-22 14:20:09', '2026-09-22 17:57:32', 50.00, 'Rio de Janeiro', 'RJ');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `user` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `foto` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `user`, `password`, `foto`) VALUES
(1, 'Zé Lele', 'zelele', '', NULL),
(2, 'Mary Zica', 'mazi', '786098767869', NULL),
(3, 'Fugiru Nakombi', 'fugina', '623485634753234', NULL),
(6, 'usuario', 'usususuario', '$2y$10$.zcqhreZBOL6cWBV1nqqde.4.0t6ZP/sV1do/gj6QfenRfTuC2kwC', 'estou entre.png'),
(7, 'teste2', 'teste2', '$2y$10$sft44WDAM2iv0le9wvnfjOJdPoxiKauxL8MqjFxOSHR6QUETqsVAa', '');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `imoveis`
--
ALTER TABLE `imoveis`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `imoveis`
--
ALTER TABLE `imoveis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
