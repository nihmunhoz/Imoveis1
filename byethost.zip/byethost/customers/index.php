<?php
    include "functions.php";
    index();
 	include HEADER_TEMPLATE; ?>

<style>
	.alinha{
		text-align: center;
	}

	.margem-botao{
		margin: 2px;
	}
</style>

<header>
	<div class="row">
		<div class="col-sm-6">
			<h2>Clientes</h2>
		</div>
		<div class="col-sm-6 text-end h2">
	    	<?php if (usuario_logado()) : ?><a class="btn btn-azul" href="add.php"><i class="fa fa-user-plus"></i> Novo Cliente</a><?php endif; ?>
	    	<a class="btn btn-atu" href="index.php"><i class="fa fa-refresh"></i> Atualizar</a>
	    </div>
	</div>
</header>

<?php if (!empty($_SESSION['message'])) : ?>
	<div class="alert alert-<?php echo $_SESSION['type']; ?> alert-dismissible" role="alert">
		<button type="button" class="close" data-bs-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<?php echo $_SESSION['message']; ?>
	</div>
<?php //clear_messages(); ?>
<?php endif; ?>

<hr>

<table class="table table-hover">
	<thead>
		<tr>
			<th class="alinha">ID</th>
			<th class="alinha" width="25%">Nome</th>
			<th class="alinha some">CPF/CNPJ</th>
			<th class="alinha some">Telefone</th>
			<th class="alinha">Atualizado em</th>
			<th class="alinha">Opções</th>
		</tr>
	</thead>

	<tbody>
		<?php if ($customers) : ?>
		<?php foreach ($customers as $customer) : ?>
			<tr>
				<td class="alinha"><?= $customer['id']; ?></td>
				<td class="alinha"><?php echo $customer['name']; ?></td>
				<td class="alinha some"><?= $customer['cpf_cnpj']; ?></td>
				<td class="alinha some"><?= $customer['mobile']; ?></td>
				<td class="alinha"><?php 
						$dt = new DateTime($customer['modified'], new DateTimeZone("-0300")); // ou America/Sao_Paulo
						echo $dt-> format("d/m/Y - H:i:s" );
					?>
				</td>
				<td class="actions text-end">

					<a href="view.php?id=<?php echo $customer['id']; ?>" class="btn-opcoes btn btn-sm btn-vizu">
						<i class="fa-solid fa-eye"></i>
						Visualizar
					</a>

					<?php if (usuario_logado()) : ?>
					<a href="edit.php?id=<?php echo $customer['id']; ?>" class="btn-opcoes btn btn-sm btn-azul">
						<i class="fa-solid fa-pencil"></i>
						Editar
					</a>

					<a href="#" class="btn-opcoes btn btn-sm btn-dark" data-bs-toggle="modal" data-bs-target="#delete-modal" data-customer="<?php echo $customer['id']; ?>">
						<i class="fa-solid fa-trash-can"></i>
						Excluir
					</a>
					<?php endif; ?>

				</td>
			</tr>
		<?php endforeach; ?>
		<?php else: ?>
			<tr>
				<td colspan="6">Nenhum registro encontrado.</td>
			</tr>
		<?php endif; ?>
	</tbody>
</table>

<?php 
include "modal.php";
include FOOTER_TEMPLATE;
?>