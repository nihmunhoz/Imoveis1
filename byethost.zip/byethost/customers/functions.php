<?php

ob_start();
include "../config.php";
require_once ABSPATH . "inc/permissoes.php";
include DBAPI;

$customers = null;
$customer = null;

/**
 *  Listagem de Clientes
 */
function index() {
	global $customers;
	$customers = find_all("customers");
}

/**
 *  Formata as datas
 */
function formataData($data, $formato) 
{
  $dt = new DateTime($data, new DateTimeZone("-0300"));
  return $dt->format($formato);
}

/*Formatar o telefone*/ 
function telefone($tel)  /* (12) 34567-8900*/
{
  return "(".substr($tel,0,2).") " . substr($tel,2,5) . "-" 
    . substr($tel,7,4);
}

/* Formatar o CPF */ 
function cpf($CPF) /* 123.456.789-00 ou 12.345.678.9012-34*/ 
{
  if (mb_strlen($CPF, 'UTF-8') <= 11){ //se for cpf
    return substr($CPF,0,3). "." . substr($CPF,3,3) . "." . substr($CPF,6,3) . "-" . substr($CPF,9,2);
  } else { //se for cnpj
    return substr($CPF,0,2). "." . substr($CPF,2,3) . "." . substr($CPF,5,3) . "/" . substr($CPF,8,4) . "-" . substr($CPF,12,2);
  }
}
function cep($CEP) /* 12345-67 */ 
{
  return substr($CEP,0,5). "-" . substr($CEP,5,3) ;
}

function view($id = null) {
  global $customer;
  $customer = find("customers", $id);
}

/*  Cadastro de Clientes */
function add()
{
  exigir_escrita();
  {
    if (!empty($_POST["customer"])) {
      
      $today = date_create("now", new DateTimeZone("America/Sao_Paulo"));  // ou ("-0300)

      $customer = $_POST["customer"];
      $customer["modified"] = $customer["created"] = $today->format("Y-m-d H:i:s");
      
      save("customers", $customer);
      header("location: index.php");
    }
  } 
}


function edit()
{
  exigir_escrita();

  $now = new DateTime("now", new DateTimeZone("-0300"));

  if (isset($_GET['id'])){

    $id = $_GET['id'];

    if (isset($_POST['customer'])){
      $customer = $_POST['customer'];
      $customer['modified'] = $now->format('Y-m-d H:i:s');
  
      update("customers", $id, $customer);
      header("location: index.php");
   } else {
      global $customer;
      $customer = find("customers", $id);
   }

  } else {
    header("location: index.php");
  }
}

function delete($id = null) {
  exigir_escrita();

  global $customer;
  $customer = remove('customers', $id);

  header('location: index.php');
}
