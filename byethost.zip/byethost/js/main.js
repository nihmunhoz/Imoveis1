
// Passa os dados do cliente para o Modal, e atualiza o link para exclusão
$('#delete-modal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var id = button.data('customer');

    var modal = $(this);
    modal.find('.modal.title').text("Excluir Cliente: " + id);
    modal.find('.modal.body').text('Deseja realmente excluir este Cliente? (id: ' +  id + ')');
    modal.find('#confirm').attr('href', 'delete.php?id=' + id);
})

/* Modal de exclusão de usuários */
$('#delete-user-modal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var deleteUrl = button.data('delete-url');
    var modal = $(this);

    modal.find('#confirm').attr('href', deleteUrl);
});

/* Modal de deletar do imóveis */
$('#delete-modal-imovel').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var deleteUrl = button.data('delete-url');
    var modal = $(this);

    modal.find('#confirm-imovel').attr('href', deleteUrl);
});

function tabelaResponsiva() {
    var largura = $(window).width();


    if (largura < 800) {
        $('.some').hide();
        $('.btn-opcoes').addClass('margem-botao');
    } else {   
        $('.some').show();
        $('.btn-opcoes').removeClass('margem-botao');
    }
}

$(document).ready(function () {
    tabelaResponsiva();
    $(window).resize(function () {
        tabelaResponsiva();
    });
});


/* 
versões que deram errado:

$('#delete-modal-imovel').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var id = button.data('imovel');

    var modal = $(this);
    modal.find('.modal.title').text("Excluir imóvel: " + id);
    modal.find('.modal.body').text('Deseja realmente excluir este imóvel? (id: ' +  id + ')');
    modal.find('#confirm').attr('href', 'delete.php?id=' + id);
})

$('#delete-modal-imovel').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var id = button.data('imovel');

    var modal = $(this);
    modal.find('#confirm').attr('href', 'delete.php?id=' + id);
});

const deleteModalImovel = document.getElementById('delete-modal-imovel');
if (deleteModalImovel) {
    deleteModalImovel.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const id = button.getAttribute('data-imovel');

        const confirmButton = deleteModalImovel.querySelector('#confirm');

        confirmButton.href = 'delete.php?id=' + id;
    });
}
*/